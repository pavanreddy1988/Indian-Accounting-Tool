import { faker } from '@faker-js/faker';
import { Account, JournalEntry, DepreciationAsset, GSTReturn, Invoice } from '../types/accounting';

export const generateMockAccounts = (): Account[] => {
  const accountTypes = [
    { type: 'Asset' as const, subType: 'Current Assets', codes: ['1100', '1200', '1300'] },
    { type: 'Asset' as const, subType: 'Fixed Assets', codes: ['1400', '1500'] },
    { type: 'Liability' as const, subType: 'Current Liabilities', codes: ['2100', '2200'] },
    { type: 'Liability' as const, subType: 'Long-term Liabilities', codes: ['2300'] },
    { type: 'Equity' as const, subType: 'Capital', codes: ['3100'] },
    { type: 'Revenue' as const, subType: 'Operating Revenue', codes: ['4100', '4200'] },
    { type: 'Expense' as const, subType: 'Operating Expenses', codes: ['5100', '5200', '5300'] },
  ];

  const accounts: Account[] = [];
  
  accountTypes.forEach(({ type, subType, codes }) => {
    codes.forEach(code => {
      accounts.push({
        id: faker.string.uuid(),
        code,
        name: `${subType} - ${code}`,
        type,
        subType,
        balance: parseFloat((Math.random() * 500000).toFixed(2)),
        openingBalance: parseFloat((Math.random() * 400000).toFixed(2)),
        isActive: true
      });
    });
  });

  return accounts;
};

export const generateMockJournalEntries = (accounts: Account[]): JournalEntry[] => {
  const entries: JournalEntry[] = [];
  
  for (let i = 0; i < 15; i++) {
    const amount = parseFloat((Math.random() * 50000).toFixed(2));
    const debitAccount = accounts[Math.floor(Math.random() * accounts.length)];
    const creditAccount = accounts[Math.floor(Math.random() * accounts.length)];
    
    entries.push({
      id: faker.string.uuid(),
      date: faker.date.recent({ days: 90 }).toISOString().split('T')[0],
      voucherNumber: `JV-${2025}-${String(i + 1).padStart(4, '0')}`,
      description: faker.commerce.productDescription(),
      entries: [
        {
          accountId: debitAccount.id,
          accountName: debitAccount.name,
          debit: amount,
          credit: 0,
          narration: 'Debit entry'
        },
        {
          accountId: creditAccount.id,
          accountName: creditAccount.name,
          debit: 0,
          credit: amount,
          narration: 'Credit entry'
        }
      ],
      createdBy: faker.person.fullName(),
      status: 'Posted'
    });
  }
  
  return entries;
};

export const generateMockDepreciationAssets = (): DepreciationAsset[] => {
  const assets: DepreciationAsset[] = [];
  const categories = ['Computer Equipment', 'Furniture', 'Vehicles', 'Machinery', 'Building'];
  
  for (let i = 0; i < 10; i++) {
    const purchaseValue = parseFloat((Math.random() * 500000 + 50000).toFixed(2));
    const rate = [10, 15, 20, 25, 30][Math.floor(Math.random() * 5)];
    const accumulated = parseFloat((purchaseValue * (rate / 100) * Math.random() * 3).toFixed(2));
    
    assets.push({
      id: faker.string.uuid(),
      assetName: faker.commerce.productName(),
      assetCode: `AST-${String(i + 1).padStart(4, '0')}`,
      category: categories[Math.floor(Math.random() * categories.length)],
      purchaseDate: faker.date.past({ years: 3 }).toISOString().split('T')[0],
      purchaseValue,
      depreciationMethod: Math.random() > 0.5 ? 'SLM' : 'WDV',
      depreciationRate: rate,
      accumulatedDepreciation: accumulated,
      writtenDownValue: purchaseValue - accumulated,
      usefulLife: Math.floor(100 / rate)
    });
  }
  
  return assets;
};

export const generateMockGSTReturns = (): GSTReturn[] => {
  const returns: GSTReturn[] = [];
  const months = ['January', 'February', 'March', 'April', 'May', 'June'];
  
  months.forEach((month, index) => {
    const sales = parseFloat((Math.random() * 1000000 + 500000).toFixed(2));
    const purchases = parseFloat((Math.random() * 600000 + 300000).toFixed(2));
    const outputGST = parseFloat((sales * 0.18).toFixed(2));
    const inputGST = parseFloat((purchases * 0.18).toFixed(2));
    
    returns.push({
      id: faker.string.uuid(),
      month,
      year: 2025,
      gstr1Filed: index < 3,
      gstr3bFiled: index < 3,
      totalSales: sales,
      totalPurchases: purchases,
      outputGST,
      inputGST,
      netGST: outputGST - inputGST,
      status: index < 3 ? 'Filed' : 'Pending'
    });
  });
  
  return returns;
};

export const generateMockInvoices = (): Invoice[] => {
  const invoices: Invoice[] = [];
  
  for (let i = 0; i < 12; i++) {
    const items = Array.from({ length: Math.floor(Math.random() * 3) + 1 }, () => {
      const quantity = Math.floor(Math.random() * 10) + 1;
      const rate = parseFloat((Math.random() * 5000 + 500).toFixed(2));
      const gstRate = [5, 12, 18, 28][Math.floor(Math.random() * 4)];
      const amount = parseFloat((quantity * rate).toFixed(2));
      
      return {
        description: faker.commerce.productName(),
        quantity,
        rate,
        gstRate,
        amount
      };
    });
    
    const subtotal = items.reduce((sum, item) => sum + item.amount, 0);
    const gstAmount = parseFloat((subtotal * 0.18).toFixed(2));
    
    invoices.push({
      id: faker.string.uuid(),
      invoiceNumber: `INV-${2025}-${String(i + 1).padStart(4, '0')}`,
      date: faker.date.recent({ days: 60 }).toISOString().split('T')[0],
      customerName: faker.company.name(),
      items,
      subtotal,
      cgst: parseFloat((gstAmount / 2).toFixed(2)),
      sgst: parseFloat((gstAmount / 2).toFixed(2)),
      igst: 0,
      total: parseFloat((subtotal + gstAmount).toFixed(2)),
      status: ['Draft', 'Sent', 'Paid', 'Overdue'][Math.floor(Math.random() * 4)] as any
    });
  }
  
  return invoices;
};
