import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import Sidebar from './components/Sidebar';
import Dashboard from './pages/Dashboard';
import ChartOfAccounts from './pages/ChartOfAccounts';
import JournalEntries from './pages/JournalEntries';
import TrialBalance from './pages/TrialBalance';
import ProfitLoss from './pages/ProfitLoss';
import BalanceSheet from './pages/BalanceSheet';
import Depreciation from './pages/Depreciation';
import GSTReturns from './pages/GSTReturns';
import Invoices from './pages/Invoices';
import Settings from './pages/Settings';

function App() {
  return (
    <Router>
      <div className="flex min-h-screen bg-gray-50">
        <Toaster position="top-center" reverseOrder={false} />
        <Sidebar />
        <div className="ml-64 flex-1 flex flex-col">
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/accounts" element={<ChartOfAccounts />} />
            <Route path="/journal" element={<JournalEntries />} />
            <Route path="/trial-balance" element={<TrialBalance />} />
            <Route path="/profit-loss" element={<ProfitLoss />} />
            <Route path="/balance-sheet" element={<BalanceSheet />} />
            <Route path="/depreciation" element={<Depreciation />} />
            <Route path="/gst" element={<GSTReturns />} />
            <Route path="/invoices" element={<Invoices />} />
            <Route path="/settings" element={<Settings />} />
          </Routes>
        </div>
      </div>
    </Router>
  );
}

export default App;
