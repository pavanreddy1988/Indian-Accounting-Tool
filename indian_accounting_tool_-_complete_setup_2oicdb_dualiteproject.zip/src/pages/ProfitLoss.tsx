import React from 'react';
import Header from '../components/Header';
import { Download, Printer } from 'lucide-react';
import toast from 'react-hot-toast';

const ProfitLoss: React.FC = () => {
  const revenue = [
    { name: 'Sales Revenue', amount: 3245600 },
    { name: 'Service Income', amount: 856000 },
    { name: 'Other Income', amount: 125000 }
  ];

  const expenses = [
    { name: 'Cost of Goods Sold', amount: 1245000 },
    { name: 'Salaries & Wages', amount: 850000 },
    { name: 'Rent & Utilities', amount: 225000 },
    { name: 'Marketing & Advertising', amount: 185000 },
    { name: 'Depreciation', amount: 125000 },
    { name: 'Office Expenses', amount: 95000 },
    { name: 'Professional Fees', amount: 75000 },
    { name: 'Interest Expense', amount: 45000 }
  ];

  const totalRevenue = revenue.reduce((sum, item) => sum + item.amount, 0);
  const totalExpenses = expenses.reduce((sum, item) => sum + item.amount, 0);
  const netProfit = totalRevenue - totalExpenses;

  return (
    <>
      <Header title="Profit & Loss Statement" />
      
      <main className="p-8">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h3 className="text-lg font-semibold text-gray-800">Profit & Loss Statement</h3>
            <p className="text-sm text-gray-600">For the period: 1st April 2024 to 31st January 2025</p>
          </div>
          <div className="flex gap-3">
            <button onClick={() => window.print()} className="flex items-center gap-2 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors">
              <Printer className="w-4 h-4" />
              <span className="font-medium">Print</span>
            </button>
            <button onClick={() => toast('PDF export coming soon!')} className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-indigo-600 to-indigo-700 text-white rounded-lg hover:shadow-lg transition-all">
              <Download className="w-4 h-4" />
              <span className="font-medium">Export PDF</span>
            </button>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-md border border-gray-200 overflow-hidden">
          <div className="p-6">
            <div className="mb-8">
              <h4 className="text-lg font-semibold text-gray-800 mb-4 pb-2 border-b-2 border-indigo-600">Revenue</h4>
              {revenue.map((item, idx) => (
                <div key={idx} className="flex justify-between py-3 border-b border-gray-100">
                  <span className="text-gray-700">{item.name}</span>
                  <span className="font-medium text-gray-900">₹{item.amount.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                </div>
              ))}
              <div className="flex justify-between py-3 bg-blue-50 px-4 -mx-4 mt-2 rounded-lg">
                <span className="font-semibold text-gray-800">Total Revenue</span>
                <span className="font-bold text-blue-700">₹{totalRevenue.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
              </div>
            </div>

            <div className="mb-8">
              <h4 className="text-lg font-semibold text-gray-800 mb-4 pb-2 border-b-2 border-orange-600">Expenses</h4>
              {expenses.map((item, idx) => (
                <div key={idx} className="flex justify-between py-3 border-b border-gray-100">
                  <span className="text-gray-700">{item.name}</span>
                  <span className="font-medium text-gray-900">₹{item.amount.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                </div>
              ))}
              <div className="flex justify-between py-3 bg-orange-50 px-4 -mx-4 mt-2 rounded-lg">
                <span className="font-semibold text-gray-800">Total Expenses</span>
                <span className="font-bold text-orange-700">₹{totalExpenses.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
              </div>
            </div>

            <div className={`flex justify-between py-4 px-6 -mx-6 -mb-6 rounded-b-xl ${
              netProfit >= 0 ? 'bg-gradient-to-r from-green-500 to-green-600' : 'bg-gradient-to-r from-red-500 to-red-600'
            } text-white`}>
              <span className="text-lg font-bold">{netProfit >= 0 ? 'Net Profit' : 'Net Loss'}</span>
              <span className="text-xl font-bold">₹{Math.abs(netProfit).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
            </div>
          </div>
        </div>

        <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl p-6 text-white shadow-lg">
            <p className="text-sm opacity-90 mb-2">Gross Profit Margin</p>
            <p className="text-3xl font-bold">{((netProfit / totalRevenue) * 100).toFixed(2)}%</p>
          </div>
          <div className="bg-gradient-to-br from-green-500 to-green-600 rounded-xl p-6 text-white shadow-lg">
            <p className="text-sm opacity-90 mb-2">Operating Ratio</p>
            <p className="text-3xl font-bold">{((totalExpenses / totalRevenue) * 100).toFixed(2)}%</p>
          </div>
          <div className="bg-gradient-to-br from-purple-500 to-purple-600 rounded-xl p-6 text-white shadow-lg">
            <p className="text-sm opacity-90 mb-2">Revenue per Employee</p>
            <p className="text-3xl font-bold">₹{(totalRevenue / 25).toLocaleString('en-IN', { maximumFractionDigits: 0 })}</p>
          </div>
        </div>
      </main>
    </>
  );
};

export default ProfitLoss;
