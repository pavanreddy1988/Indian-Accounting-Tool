import React, { useState, useEffect } from 'react';
import Header from '../components/Header';
import Modal from '../components/Modal';
import ViewInvoiceModal from '../components/ViewInvoiceModal';
import { Plus, Eye, Download, Trash2, Edit2 } from 'lucide-react';
import { generateMockInvoices } from '../data/mockData';
import { useForm, useFieldArray } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { Invoice } from '../types/accounting';
import toast from 'react-hot-toast';
import { faker } from '@faker-js/faker';

const invoiceItemSchema = z.object({
  description: z.string().min(1, 'Description is required'),
  quantity: z.preprocess(v => parseFloat(String(v || '0')), z.number().positive('Must be > 0')),
  rate: z.preprocess(v => parseFloat(String(v || '0')), z.number().positive('Must be > 0')),
  gstRate: z.preprocess(v => parseFloat(String(v || '0')), z.number().min(0)),
});

const invoiceSchema = z.object({
  customerName: z.string().min(3, 'Customer name is required'),
  date: z.string().min(1, 'Date is required'),
  items: z.array(invoiceItemSchema).min(1, 'At least one item is required'),
});

type InvoiceFormData = z.infer<typeof invoiceSchema>;

const Invoices: React.FC = () => {
  const [invoices, setInvoices] = useState<Invoice[]>(generateMockInvoices());
  const [isFormModalOpen, setIsFormModalOpen] = useState(false);
  const [isViewModalOpen, setIsViewModalOpen] = useState(false);
  const [editingInvoice, setEditingInvoice] = useState<Invoice | null>(null);
  const [viewingInvoice, setViewingInvoice] = useState<Invoice | null>(null);

  const { register, control, handleSubmit, reset, formState: { errors } } = useForm<InvoiceFormData>({
    resolver: zodResolver(invoiceSchema),
  });

  useEffect(() => {
    if (editingInvoice) {
      reset({
        customerName: editingInvoice.customerName,
        date: editingInvoice.date,
        items: editingInvoice.items.map(i => ({ description: i.description, quantity: i.quantity, rate: i.rate, gstRate: i.gstRate }))
      });
    } else {
      reset({
        customerName: '',
        date: new Date().toISOString().split('T')[0],
        items: [{ description: '', quantity: 1, rate: 0, gstRate: 18 }],
      });
    }
  }, [editingInvoice, reset]);

  const { fields, append, remove } = useFieldArray({
    control,
    name: 'items',
  });

  const handleFormSubmit = (data: InvoiceFormData) => {
    const itemsWithAmount = data.items.map(item => ({
      ...item,
      amount: item.quantity * item.rate,
    }));
    const subtotal = itemsWithAmount.reduce((sum, item) => sum + item.amount, 0);
    const gstAmount = itemsWithAmount.reduce((sum, item) => sum + (item.amount * item.gstRate / 100), 0);
    
    if (editingInvoice) {
      const updatedInvoice: Invoice = {
        ...editingInvoice,
        customerName: data.customerName,
        date: data.date,
        items: itemsWithAmount,
        subtotal,
        cgst: gstAmount / 2,
        sgst: gstAmount / 2,
        igst: 0,
        total: subtotal + gstAmount,
      };
      setInvoices(prev => prev.map(inv => inv.id === editingInvoice.id ? updatedInvoice : inv));
      toast.success('Invoice updated successfully!');
    } else {
      const newInvoice: Invoice = {
        id: faker.string.uuid(),
        invoiceNumber: `INV-${2025}-${String(invoices.length + 1).padStart(4, '0')}`,
        customerName: data.customerName,
        date: data.date,
        items: itemsWithAmount,
        subtotal,
        cgst: gstAmount / 2,
        sgst: gstAmount / 2,
        igst: 0,
        total: subtotal + gstAmount,
        status: 'Draft',
      };
      setInvoices(prev => [newInvoice, ...prev]);
      toast.success('Invoice created successfully!');
    }

    closeFormModal();
  };
  
  const handleDeleteInvoice = (invoiceId: string) => {
    if (window.confirm('Are you sure you want to delete this invoice?')) {
      setInvoices(prev => prev.filter(invoice => invoice.id !== invoiceId));
      toast.success('Invoice deleted successfully!');
    }
  };

  const openFormModal = (invoice: Invoice | null) => {
    setEditingInvoice(invoice);
    setIsFormModalOpen(true);
  };

  const closeFormModal = () => {
    setIsFormModalOpen(false);
    setEditingInvoice(null);
  };

  const openViewModal = (invoice: Invoice) => {
    setViewingInvoice(invoice);
    setIsViewModalOpen(true);
  };

  return (
    <div className="w-full min-h-screen bg-gray-50">
      <Header title="Invoices" />
      
      <main className="p-8">
        <div className="flex justify-between items-center mb-6">
          <p className="text-gray-600">Manage sales invoices with GST compliance</p>
          <button onClick={() => openFormModal(null)} className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-indigo-600 to-indigo-700 text-white rounded-lg hover:shadow-lg transition-all">
            <Plus className="w-4 h-4" />
            <span className="font-medium">Create Invoice</span>
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl p-6 text-white shadow-lg">
            <p className="text-sm opacity-90 mb-1">Total Invoices</p>
            <p className="text-3xl font-bold">{invoices.length}</p>
          </div>
          <div className="bg-gradient-to-br from-green-500 to-green-600 rounded-xl p-6 text-white shadow-lg">
            <p className="text-sm opacity-90 mb-1">Paid</p>
            <p className="text-3xl font-bold">{invoices.filter(i => i.status === 'Paid').length}</p>
          </div>
          <div className="bg-gradient-to-br from-orange-500 to-orange-600 rounded-xl p-6 text-white shadow-lg">
            <p className="text-sm opacity-90 mb-1">Pending</p>
            <p className="text-3xl font-bold">{invoices.filter(i => i.status === 'Sent').length}</p>
          </div>
          <div className="bg-gradient-to-br from-red-500 to-red-600 rounded-xl p-6 text-white shadow-lg">
            <p className="text-sm opacity-90 mb-1">Overdue</p>
            <p className="text-3xl font-bold">{invoices.filter(i => i.status === 'Overdue').length}</p>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-md border border-gray-200 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 border-b border-gray-200">
                <tr>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Invoice No.</th>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Date</th>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Customer</th>
                  <th className="px-6 py-4 text-right text-xs font-semibold text-gray-600 uppercase tracking-wider">Total</th>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Status</th>
                  <th className="px-6 py-4 text-center text-xs font-semibold text-gray-600 uppercase tracking-wider">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {invoices.map((invoice) => (
                  <tr key={invoice.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className="font-mono text-sm font-medium text-indigo-600">{invoice.invoiceNumber}</span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className="text-sm text-gray-900">{new Date(invoice.date).toLocaleDateString('en-IN')}</span>
                    </td>
                    <td className="px-6 py-4">
                      <span className="text-sm font-medium text-gray-900">{invoice.customerName}</span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right">
                      <span className="text-sm font-semibold text-gray-900">₹{invoice.total.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`inline-flex px-3 py-1 text-xs font-semibold rounded-full ${
                        invoice.status === 'Paid' ? 'bg-green-100 text-green-800' :
                        invoice.status === 'Sent' ? 'bg-blue-100 text-blue-800' :
                        invoice.status === 'Overdue' ? 'bg-red-100 text-red-800' :
                        'bg-gray-100 text-gray-800'
                      }`}>
                        {invoice.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-center">
                      <div className="flex items-center justify-center gap-2">
                        <button onClick={() => openViewModal(invoice)} className="p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors">
                          <Eye className="w-4 h-4" />
                        </button>
                        <button onClick={() => openFormModal(invoice)} className="p-2 text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors">
                          <Edit2 className="w-4 h-4" />
                        </button>
                        <button onClick={() => toast('PDF download coming soon!')} className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors">
                          <Download className="w-4 h-4" />
                        </button>
                        <button onClick={() => handleDeleteInvoice(invoice.id)} className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors">
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </main>
      <Modal title={editingInvoice ? "Edit Invoice" : "Create New Invoice"} isOpen={isFormModalOpen} onClose={closeFormModal}>
        <form onSubmit={handleSubmit(handleFormSubmit)} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">Customer Name</label>
              <input {...register('customerName')} className="mt-1 block w-full input" />
              {errors.customerName && <p className="text-red-500 text-xs mt-1">{errors.customerName.message}</p>}
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">Invoice Date</label>
              <input type="date" {...register('date')} className="mt-1 block w-full input" />
              {errors.date && <p className="text-red-500 text-xs mt-1">{errors.date.message}</p>}
            </div>
          </div>
          <div>
            <h4 className="text-md font-medium text-gray-800 mb-2">Items</h4>
            <div className="space-y-4">
              {fields.map((field, index) => (
                <div key={field.id} className="grid grid-cols-12 gap-2 items-start p-3 bg-gray-50 rounded-lg">
                  <div className="col-span-12 md:col-span-4">
                    <label className="text-xs text-gray-600">Description</label>
                    <input {...register(`items.${index}.description`)} className="w-full input-sm" />
                    {errors.items?.[index]?.description && <p className="text-red-500 text-xs mt-1">{errors.items?.[index]?.description?.message}</p>}
                  </div>
                  <div className="col-span-4 md:col-span-2">
                    <label className="text-xs text-gray-600">Qty</label>
                    <input type="number" {...register(`items.${index}.quantity`)} className="w-full input-sm" />
                  </div>
                  <div className="col-span-4 md:col-span-2">
                    <label className="text-xs text-gray-600">Rate</label>
                    <input type="number" {...register(`items.${index}.rate`)} className="w-full input-sm" />
                  </div>
                  <div className="col-span-4 md:col-span-2">
                    <label className="text-xs text-gray-600">GST(%)</label>
                    <input type="number" {...register(`items.${index}.gstRate`)} className="w-full input-sm" />
                  </div>
                  <div className="col-span-12 md:col-span-2 flex items-end justify-end h-full">
                    <button type="button" onClick={() => remove(index)} className="p-2 text-red-500 hover:bg-red-100 rounded-md">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
            <button type="button" onClick={() => append({ description: '', quantity: 1, rate: 0, gstRate: 18 })} className="mt-2 flex items-center gap-2 text-sm font-medium text-indigo-600 hover:text-indigo-800">
              <Plus className="w-4 h-4" /> Add Item
            </button>
            {errors.items && <p className="text-red-500 text-xs mt-1">{errors.items.message}</p>}
          </div>
          <div className="flex justify-end gap-3 pt-4 border-t">
            <button type="button" onClick={closeFormModal} className="px-4 py-2 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300">Cancel</button>
            <button type="submit" className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700">{editingInvoice ? "Save Changes" : "Create Invoice"}</button>
          </div>
        </form>
      </Modal>
      <ViewInvoiceModal isOpen={isViewModalOpen} onClose={() => setIsViewModalOpen(false)} invoice={viewingInvoice} />
    </div>
  );
};

export default Invoices;
