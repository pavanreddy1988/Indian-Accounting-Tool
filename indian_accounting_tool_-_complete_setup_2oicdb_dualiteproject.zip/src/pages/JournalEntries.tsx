import React, { useState, useMemo, useEffect } from 'react';
import Header from '../components/Header';
import Modal from '../components/Modal';
import { Plus, Eye, Edit2, Trash2 } from 'lucide-react';
import { generateMockAccounts, generateMockJournalEntries } from '../data/mockData';
import { useForm, useFieldArray } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { JournalEntry, TransactionEntry } from '../types/accounting';
import toast from 'react-hot-toast';
import { faker } from '@faker-js/faker';

const transactionEntrySchema = z.object({
  accountId: z.string().min(1, 'Account is required'),
  debit: z.preprocess((v) => parseFloat(String(v || '0')), z.number().min(0)),
  credit: z.preprocess((v) => parseFloat(String(v || '0')), z.number().min(0)),
  narration: z.string().optional(),
}).refine(data => !(data.debit > 0 && data.credit > 0), {
  message: 'Enter either a debit or a credit, not both.',
  path: ['debit'],
});

const journalEntrySchema = z.object({
  description: z.string().min(3, 'Description is required'),
  date: z.string().min(1, 'Date is required'),
  entries: z.array(transactionEntrySchema).min(2, 'At least two entries are required'),
}).refine(data => {
  const totalDebit = data.entries.reduce((sum, entry) => sum + entry.debit, 0);
  const totalCredit = data.entries.reduce((sum, entry) => sum + entry.credit, 0);
  return Math.abs(totalDebit - totalCredit) < 0.01;
}, {
  message: 'Total debits must equal total credits.',
  path: ['entries'],
});

type JournalFormData = z.infer<typeof journalEntrySchema>;

const JournalEntries: React.FC = () => {
  const [accounts] = useState(generateMockAccounts());
  const [entries, setEntries] = useState(generateMockJournalEntries(accounts));
  const [isFormModalOpen, setIsFormModalOpen] = useState(false);
  const [isViewModalOpen, setIsViewModalOpen] = useState(false);
  const [editingEntry, setEditingEntry] = useState<JournalEntry | null>(null);
  const [viewingEntry, setViewingEntry] = useState<JournalEntry | null>(null);

  const { register, control, handleSubmit, reset, watch, formState: { errors } } = useForm<JournalFormData>({
    resolver: zodResolver(journalEntrySchema),
  });

  useEffect(() => {
    if (editingEntry) {
      reset({
        description: editingEntry.description,
        date: editingEntry.date,
        entries: editingEntry.entries.map(e => ({ accountId: e.accountId, debit: e.debit, credit: e.credit, narration: e.narration }))
      });
    } else {
      reset({
        description: '',
        date: new Date().toISOString().split('T')[0],
        entries: [
          { accountId: '', debit: 0, credit: 0, narration: '' },
          { accountId: '', debit: 0, credit: 0, narration: '' },
        ],
      });
    }
  }, [editingEntry, reset]);

  const { fields, append, remove } = useFieldArray({
    control,
    name: 'entries',
  });

  const watchedEntries = watch('entries');
  const { totalDebit, totalCredit } = useMemo(() => {
    return (watchedEntries || []).reduce((acc, entry) => {
      acc.totalDebit += Number(entry.debit) || 0;
      acc.totalCredit += Number(entry.credit) || 0;
      return acc;
    }, { totalDebit: 0, totalCredit: 0 });
  }, [watchedEntries]);

  const handleFormSubmit = (data: JournalFormData) => {
    const formattedEntries: TransactionEntry[] = data.entries.map(e => ({
      ...e,
      accountName: accounts.find(acc => acc.id === e.accountId)?.name || 'Unknown',
    }));

    if (editingEntry) {
      const updatedEntry: JournalEntry = {
        ...editingEntry,
        description: data.description,
        date: data.date,
        entries: formattedEntries,
      };
      setEntries(prev => prev.map(e => e.id === editingEntry.id ? updatedEntry : e));
      toast.success('Journal entry updated successfully!');
    } else {
      const newEntry: JournalEntry = {
        id: faker.string.uuid(),
        voucherNumber: `JV-${2025}-${String(entries.length + 1).padStart(4, '0')}`,
        description: data.description,
        date: data.date,
        entries: formattedEntries,
        createdBy: 'Admin User',
        status: 'Posted',
      };
      setEntries(prev => [newEntry, ...prev]);
      toast.success('Journal entry created successfully!');
    }
    closeFormModal();
  };

  const handleDeleteEntry = (entryId: string) => {
    if (window.confirm('Are you sure you want to delete this journal entry?')) {
      setEntries(prev => prev.filter(entry => entry.id !== entryId));
      toast.success('Journal entry deleted successfully!');
    }
  };

  const openFormModal = (entry: JournalEntry | null) => {
    setEditingEntry(entry);
    setIsFormModalOpen(true);
  };
  
  const closeFormModal = () => {
    setIsFormModalOpen(false);
    setEditingEntry(null);
  };

  const openViewModal = (entry: JournalEntry) => {
    setViewingEntry(entry);
    setIsViewModalOpen(true);
  };

  return (
    <div className="w-full min-h-screen bg-gray-50">
      <Header title="Journal Entries" />
      
      <main className="p-8">
        <div className="flex justify-between items-center mb-6">
          <p className="text-gray-600">Manage all journal entries and vouchers</p>
          <button onClick={() => openFormModal(null)} className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-indigo-600 to-indigo-700 text-white rounded-lg hover:shadow-lg transition-all">
            <Plus className="w-4 h-4" />
            <span className="font-medium">New Journal Entry</span>
          </button>
        </div>

        <div className="bg-white rounded-xl shadow-md border border-gray-200 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 border-b border-gray-200">
                <tr>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Voucher No.</th>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Date</th>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Description</th>
                  <th className="px-6 py-4 text-right text-xs font-semibold text-gray-600 uppercase tracking-wider">Debit</th>
                  <th className="px-6 py-4 text-right text-xs font-semibold text-gray-600 uppercase tracking-wider">Credit</th>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Status</th>
                  <th className="px-6 py-4 text-center text-xs font-semibold text-gray-600 uppercase tracking-wider">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {entries.map((entry) => {
                  const totalDebit = entry.entries.reduce((sum, e) => sum + e.debit, 0);
                  const totalCredit = entry.entries.reduce((sum, e) => sum + e.credit, 0);
                  
                  return (
                    <tr key={entry.id} className="hover:bg-gray-50 transition-colors">
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className="font-mono text-sm font-medium text-indigo-600">{entry.voucherNumber}</span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className="text-sm text-gray-900">{new Date(entry.date).toLocaleDateString('en-IN')}</span>
                      </td>
                      <td className="px-6 py-4">
                        <div>
                          <p className="text-sm font-medium text-gray-900">{entry.description}</p>
                          <p className="text-xs text-gray-500 mt-1">By {entry.createdBy}</p>
                        </div>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right">
                        <span className="text-sm font-medium text-gray-900">₹{totalDebit.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-right">
                        <span className="text-sm font-medium text-gray-900">₹{totalCredit.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap">
                        <span className={`inline-flex px-3 py-1 text-xs font-semibold rounded-full ${
                          entry.status === 'Posted' ? 'bg-green-100 text-green-800' :
                          entry.status === 'Draft' ? 'bg-yellow-100 text-yellow-800' :
                          'bg-red-100 text-red-800'
                        }`}>
                          {entry.status}
                        </span>
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-center">
                        <div className="flex items-center justify-center gap-2">
                          <button onClick={() => openViewModal(entry)} className="p-2 text-gray-600 hover:bg-gray-100 rounded-lg transition-colors">
                            <Eye className="w-4 h-4" />
                          </button>
                          <button onClick={() => openFormModal(entry)} className="p-2 text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors">
                            <Edit2 className="w-4 h-4" />
                          </button>
                          <button onClick={() => handleDeleteEntry(entry.id)} className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors">
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      </main>

      <Modal title={editingEntry ? "Edit Journal Entry" : "New Journal Entry"} isOpen={isFormModalOpen} onClose={closeFormModal}>
        <form onSubmit={handleSubmit(handleFormSubmit)} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">Description</label>
              <input {...register('description')} className="mt-1 block w-full input" />
              {errors.description && <p className="text-red-500 text-xs mt-1">{errors.description.message}</p>}
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">Date</label>
              <input type="date" {...register('date')} className="mt-1 block w-full input" />
              {errors.date && <p className="text-red-500 text-xs mt-1">{errors.date.message}</p>}
            </div>
          </div>
          
          <div>
            <h4 className="text-md font-medium text-gray-800 mb-2">Transactions</h4>
            <div className="space-y-3">
              {fields.map((field, index) => (
                <div key={field.id} className="grid grid-cols-12 gap-2 items-start p-3 bg-gray-50 rounded-lg">
                  <div className="col-span-12 md:col-span-5">
                    <label className="text-xs text-gray-600">Account</label>
                    <select {...register(`entries.${index}.accountId`)} className="w-full input-sm">
                      <option value="">Select Account</option>
                      {accounts.map(acc => <option key={acc.id} value={acc.id}>{acc.code} - {acc.name}</option>)}
                    </select>
                    {errors.entries?.[index]?.accountId && <p className="text-red-500 text-xs mt-1">{errors.entries?.[index]?.accountId?.message}</p>}
                  </div>
                  <div className="col-span-6 md:col-span-3">
                    <label className="text-xs text-gray-600">Debit (₹)</label>
                    <input type="number" step="0.01" {...register(`entries.${index}.debit`)} className="w-full input-sm" />
                  </div>
                  <div className="col-span-6 md:col-span-3">
                    <label className="text-xs text-gray-600">Credit (₹)</label>
                    <input type="number" step="0.01" {...register(`entries.${index}.credit`)} className="w-full input-sm" />
                  </div>
                  <div className="col-span-11">
                     {errors.entries?.[index]?.debit && <p className="text-red-500 text-xs mt-1">{errors.entries?.[index]?.debit?.message}</p>}
                  </div>
                  <div className="col-span-1 flex items-end justify-end h-full">
                    <button type="button" onClick={() => remove(index)} className="p-2 text-red-500 hover:bg-red-100 rounded-md">
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
            <button type="button" onClick={() => append({ accountId: '', debit: 0, credit: 0, narration: '' })} className="mt-3 flex items-center gap-2 text-sm font-medium text-indigo-600 hover:text-indigo-800">
              <Plus className="w-4 h-4" /> Add Row
            </button>
            {errors.entries && <p className="text-red-500 text-xs mt-1">{errors.entries.message}</p>}
          </div>

          <div className="flex justify-between items-center p-3 bg-gray-100 rounded-lg">
              <div className="text-sm font-medium">Totals</div>
              <div className="flex gap-6 text-sm">
                  <div className="text-right">
                      <span className="text-gray-600">Debit: </span>
                      <span className="font-semibold text-gray-800">₹{totalDebit.toFixed(2)}</span>
                  </div>
                   <div className="text-right">
                      <span className="text-gray-600">Credit: </span>
                      <span className="font-semibold text-gray-800">₹{totalCredit.toFixed(2)}</span>
                  </div>
              </div>
          </div>
          {Math.abs(totalDebit - totalCredit) > 0.01 && <p className="text-red-500 text-xs text-center">Totals do not balance!</p>}

          <div className="flex justify-end gap-3 pt-4 border-t">
            <button type="button" onClick={closeFormModal} className="px-4 py-2 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300">Cancel</button>
            <button type="submit" className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700">{editingEntry ? "Save Changes" : "Create Entry"}</button>
          </div>
        </form>
      </Modal>

      {viewingEntry && (
        <Modal title={`View Entry: ${viewingEntry.voucherNumber}`} isOpen={isViewModalOpen} onClose={() => setIsViewModalOpen(false)}>
          <div className="space-y-4">
            <p><strong>Date:</strong> {new Date(viewingEntry.date).toLocaleDateString('en-IN')}</p>
            <p><strong>Description:</strong> {viewingEntry.description}</p>
            <table className="w-full text-sm">
              <thead className="bg-gray-100">
                <tr>
                  <th className="p-2 text-left">Account</th>
                  <th className="p-2 text-right">Debit</th>
                  <th className="p-2 text-right">Credit</th>
                </tr>
              </thead>
              <tbody>
                {viewingEntry.entries.map((e, i) => (
                  <tr key={i} className="border-b">
                    <td className="p-2">{e.accountName}</td>
                    <td className="p-2 text-right">{e.debit > 0 ? `₹${e.debit.toFixed(2)}` : '-'}</td>
                    <td className="p-2 text-right">{e.credit > 0 ? `₹${e.credit.toFixed(2)}` : '-'}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Modal>
      )}
    </div>
  );
};

export default JournalEntries;
