import React, { useState } from 'react';
import Header from '../components/Header';
import { Download, Printer } from 'lucide-react';
import { generateMockAccounts } from '../data/mockData';
import toast from 'react-hot-toast';

const TrialBalance: React.FC = () => {
  const [accounts] = useState(generateMockAccounts());

  const trialBalanceData = accounts.map(acc => ({
    code: acc.code,
    name: acc.name,
    debit: ['Asset', 'Expense'].includes(acc.type) ? acc.balance : 0,
    credit: ['Liability', 'Equity', 'Revenue'].includes(acc.type) ? acc.balance : 0
  }));

  const totalDebit = trialBalanceData.reduce((sum, item) => sum + item.debit, 0);
  const totalCredit = trialBalanceData.reduce((sum, item) => sum + item.credit, 0);

  return (
    <>
      <Header title="Trial Balance" />
      
      <main className="p-8">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h3 className="text-lg font-semibold text-gray-800">Trial Balance Report</h3>
            <p className="text-sm text-gray-600">As on 31st January 2025</p>
          </div>
          <div className="flex gap-3">
            <button onClick={() => window.print()} className="flex items-center gap-2 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors">
              <Printer className="w-4 h-4" />
              <span className="font-medium">Print</span>
            </button>
            <button onClick={() => toast('PDF export coming soon!')} className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-indigo-600 to-indigo-700 text-white rounded-lg hover:shadow-lg transition-all">
              <Download className="w-4 h-4" />
              <span className="font-medium">Export PDF</span>
            </button>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-md border border-gray-200 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gradient-to-r from-indigo-600 to-indigo-700 text-white">
                <tr>
                  <th className="px-6 py-4 text-left text-sm font-semibold uppercase tracking-wider">Account Code</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold uppercase tracking-wider">Account Name</th>
                  <th className="px-6 py-4 text-right text-sm font-semibold uppercase tracking-wider">Debit (₹)</th>
                  <th className="px-6 py-4 text-right text-sm font-semibold uppercase tracking-wider">Credit (₹)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {trialBalanceData.map((item, idx) => (
                  <tr key={idx} className="hover:bg-gray-50 transition-colors">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className="font-mono text-sm font-medium text-gray-900">{item.code}</span>
                    </td>
                    <td className="px-6 py-4">
                      <span className="text-sm font-medium text-gray-900">{item.name}</span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right">
                      <span className="text-sm font-medium text-gray-900">
                        {item.debit > 0 ? item.debit.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : '-'}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right">
                      <span className="text-sm font-medium text-gray-900">
                        {item.credit > 0 ? item.credit.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }) : '-'}
                      </span>
                    </td>
                  </tr>
                ))}
                <tr className="bg-indigo-50 font-bold">
                  <td colSpan={2} className="px-6 py-4 text-right text-sm font-bold text-gray-900 uppercase">Total</td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-bold text-gray-900">
                    ₹{totalDebit.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-bold text-gray-900">
                    ₹{totalCredit.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </td>
                </tr>
                <tr className={`${Math.abs(totalDebit - totalCredit) < 0.01 ? 'bg-green-50' : 'bg-red-50'}`}>
                  <td colSpan={2} className="px-6 py-4 text-right text-sm font-bold text-gray-900 uppercase">Difference</td>
                  <td colSpan={2} className={`px-6 py-4 text-center text-sm font-bold ${
                    Math.abs(totalDebit - totalCredit) < 0.01 ? 'text-green-700' : 'text-red-700'
                  }`}>
                    {Math.abs(totalDebit - totalCredit) < 0.01 ? 
                      '✓ Balanced' : 
                      `₹${Math.abs(totalDebit - totalCredit).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`
                    }
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        <div className="mt-6 bg-blue-50 border border-blue-200 rounded-lg p-4">
          <p className="text-sm text-blue-800">
            <strong>Note:</strong> This Trial Balance includes all posted transactions up to the date mentioned above. 
            Ensure all journal entries are posted before generating financial statements.
          </p>
        </div>
      </main>
    </>
  );
};

export default TrialBalance;
