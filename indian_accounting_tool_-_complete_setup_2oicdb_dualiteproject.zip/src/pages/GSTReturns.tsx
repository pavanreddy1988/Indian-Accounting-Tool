import React, { useState } from 'react';
import Header from '../components/Header';
import { FileCheck, FileX, Download } from 'lucide-react';
import { generateMockGSTReturns } from '../data/mockData';
import toast from 'react-hot-toast';

const GSTReturns: React.FC = () => {
  const [returns] = useState(generateMockGSTReturns());

  return (
    <>
      <Header title="GST Returns" />
      
      <main className="p-8">
        <div className="flex justify-between items-center mb-6">
          <p className="text-gray-600">Manage GST filings and track return status</p>
          <button onClick={() => toast('Download functionality coming soon!')} className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-indigo-600 to-indigo-700 text-white rounded-lg hover:shadow-lg transition-all">
            <Download className="w-4 h-4" />
            <span className="font-medium">Download Returns</span>
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-gradient-to-br from-green-500 to-green-600 rounded-xl p-6 text-white shadow-lg">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm opacity-90 mb-1">Returns Filed</p>
                <p className="text-3xl font-bold">{returns.filter(r => r.status === 'Filed').length}</p>
              </div>
              <FileCheck className="w-10 h-10 opacity-80" />
            </div>
          </div>

          <div className="bg-gradient-to-br from-orange-500 to-orange-600 rounded-xl p-6 text-white shadow-lg">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm opacity-90 mb-1">Pending Returns</p>
                <p className="text-3xl font-bold">{returns.filter(r => r.status === 'Pending').length}</p>
              </div>
              <FileX className="w-10 h-10 opacity-80" />
            </div>
          </div>

          <div className="bg-gradient-to-br from-purple-500 to-purple-600 rounded-xl p-6 text-white shadow-lg">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-sm opacity-90 mb-1">Net GST Payable</p>
                <p className="text-2xl font-bold">
                  ₹{returns.reduce((sum, r) => sum + r.netGST, 0).toLocaleString('en-IN', { maximumFractionDigits: 0 })}
                </p>
              </div>
              <FileCheck className="w-10 h-10 opacity-80" />
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-md border border-gray-200 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 border-b border-gray-200">
                <tr>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Period</th>
                  <th className="px-6 py-4 text-right text-xs font-semibold text-gray-600 uppercase tracking-wider">Total Sales</th>
                  <th className="px-6 py-4 text-right text-xs font-semibold text-gray-600 uppercase tracking-wider">Total Purchases</th>
                  <th className="px-6 py-4 text-right text-xs font-semibold text-gray-600 uppercase tracking-wider">Output GST</th>
                  <th className="px-6 py-4 text-right text-xs font-semibold text-gray-600 uppercase tracking-wider">Input GST</th>
                  <th className="px-6 py-4 text-right text-xs font-semibold text-gray-600 uppercase tracking-wider">Net GST</th>
                  <th className="px-6 py-4 text-center text-xs font-semibold text-gray-600 uppercase tracking-wider">GSTR-1</th>
                  <th className="px-6 py-4 text-center text-xs font-semibold text-gray-600 uppercase tracking-wider">GSTR-3B</th>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {returns.map((ret) => (
                  <tr key={ret.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className="text-sm font-medium text-gray-900">{ret.month} {ret.year}</span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right">
                      <span className="text-sm font-medium text-gray-900">₹{ret.totalSales.toLocaleString('en-IN', { maximumFractionDigits: 0 })}</span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right">
                      <span className="text-sm font-medium text-gray-900">₹{ret.totalPurchases.toLocaleString('en-IN', { maximumFractionDigits: 0 })}</span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right">
                      <span className="text-sm font-medium text-green-600">₹{ret.outputGST.toLocaleString('en-IN', { maximumFractionDigits: 0 })}</span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right">
                      <span className="text-sm font-medium text-blue-600">₹{ret.inputGST.toLocaleString('en-IN', { maximumFractionDigits: 0 })}</span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right">
                      <span className={`text-sm font-semibold ${ret.netGST >= 0 ? 'text-red-600' : 'text-green-600'}`}>
                        ₹{Math.abs(ret.netGST).toLocaleString('en-IN', { maximumFractionDigits: 0 })}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-center">
                      {ret.gstr1Filed ? (
                        <span className="inline-flex items-center gap-1 px-3 py-1 text-xs font-semibold rounded-full bg-green-100 text-green-800">
                          <FileCheck className="w-3 h-3" />
                          Filed
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 px-3 py-1 text-xs font-semibold rounded-full bg-red-100 text-red-800">
                          <FileX className="w-3 h-3" />
                          Pending
                        </span>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-center">
                      {ret.gstr3bFiled ? (
                        <span className="inline-flex items-center gap-1 px-3 py-1 text-xs font-semibold rounded-full bg-green-100 text-green-800">
                          <FileCheck className="w-3 h-3" />
                          Filed
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 px-3 py-1 text-xs font-semibold rounded-full bg-red-100 text-red-800">
                          <FileX className="w-3 h-3" />
                          Pending
                        </span>
                      )}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`inline-flex px-3 py-1 text-xs font-semibold rounded-full ${
                        ret.status === 'Filed' ? 'bg-green-100 text-green-800' :
                        ret.status === 'Pending' ? 'bg-orange-100 text-orange-800' :
                        'bg-blue-100 text-blue-800'
                      }`}>
                        {ret.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="mt-6 bg-amber-50 border border-amber-200 rounded-lg p-4">
          <h4 className="font-semibold text-amber-900 mb-2">Important Deadlines</h4>
          <ul className="space-y-1 text-sm text-amber-800">
            <li>• GSTR-1: 11th of next month</li>
            <li>• GSTR-3B: 20th of next month</li>
            <li>• Annual Return (GSTR-9): 31st December of next financial year</li>
          </ul>
        </div>
      </main>
    </>
  );
};

export default GSTReturns;
