import React, { useState } from 'react';
import Header from '../components/Header';
import { Building2, User, Lock, FileText } from 'lucide-react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import toast from 'react-hot-toast';

// Schema for Company Information
const companyInfoSchema = z.object({
  companyName: z.string().min(3, 'Company name is required'),
  gstin: z.string().regex(/^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/, 'Invalid GSTIN format'),
  pan: z.string().regex(/[A-Z]{5}[0-9]{4}[A-Z]{1}/, 'Invalid PAN format'),
});
type CompanyInfoFormData = z.infer<typeof companyInfoSchema>;

// Schema for User Profile
const userProfileSchema = z.object({
  fullName: z.string().min(3, 'Full name is required'),
  email: z.string().email('Invalid email address'),
  role: z.enum(['Accountant', 'Manager', 'Admin']),
});
type UserProfileFormData = z.infer<typeof userProfileSchema>;

// Schema for Security (Password Change)
const securitySchema = z.object({
  currentPassword: z.string().min(6, 'Password must be at least 6 characters'),
  newPassword: z.string().min(6, 'Password must be at least 6 characters'),
  confirmPassword: z.string().min(6, 'Password must be at least 6 characters'),
}).refine(data => data.newPassword === data.confirmPassword, {
  message: "New passwords don't match",
  path: ['confirmPassword'],
});
type SecurityFormData = z.infer<typeof securitySchema>;

// Schema for Accounting Preferences
const preferencesSchema = z.object({
  financialYear: z.string(),
  dateFormat: z.enum(['DD/MM/YYYY', 'MM/DD/YYYY', 'YYYY-MM-DD']),
});
type PreferencesFormData = z.infer<typeof preferencesSchema>;


const Settings: React.FC = () => {
  const [companyInfo, setCompanyInfo] = useState<CompanyInfoFormData>({
    companyName: 'AccounTech Solutions Pvt. Ltd.',
    gstin: '29AABCU9603R1ZX',
    pan: 'AABCU9603R',
  });

  const [userProfile, setUserProfile] = useState<UserProfileFormData>({
    fullName: 'Admin User',
    email: 'admin@accountech.com',
    role: 'Accountant',
  });
  
  const [preferences, setPreferences] = useState<PreferencesFormData>({
    financialYear: '2024-2025',
    dateFormat: 'DD/MM/YYYY',
  });

  const {
    register: registerCompany,
    handleSubmit: handleSubmitCompany,
    formState: { errors: errorsCompany },
  } = useForm<CompanyInfoFormData>({
    resolver: zodResolver(companyInfoSchema),
    values: companyInfo,
  });

  const {
    register: registerProfile,
    handleSubmit: handleSubmitProfile,
    formState: { errors: errorsProfile },
  } = useForm<UserProfileFormData>({
    resolver: zodResolver(userProfileSchema),
    values: userProfile,
  });

  const {
    register: registerSecurity,
    handleSubmit: handleSubmitSecurity,
    reset: resetSecurity,
    formState: { errors: errorsSecurity },
  } = useForm<SecurityFormData>({
    resolver: zodResolver(securitySchema),
  });

  const {
    register: registerPrefs,
    handleSubmit: handleSubmitPrefs,
    formState: { errors: errorsPrefs },
  } = useForm<PreferencesFormData>({
    resolver: zodResolver(preferencesSchema),
    values: preferences,
  });

  const onCompanyInfoSubmit = (data: CompanyInfoFormData) => {
    setCompanyInfo(data);
    toast.success('Company information saved successfully!');
  };

  const onProfileSubmit = (data: UserProfileFormData) => {
    setUserProfile(data);
    toast.success('User profile updated successfully!');
  };

  const onSecuritySubmit = (data: SecurityFormData) => {
    console.log('Password Changed:', data); // In a real app, this would call an API
    toast.success('Password changed successfully!');
    resetSecurity();
  };

  const onPrefsSubmit = (data: PreferencesFormData) => {
    setPreferences(data);
    toast.success('Accounting preferences saved successfully!');
  };

  return (
    <div className="w-full min-h-screen bg-gray-50">
      <Header title="Settings" />
      
      <main className="p-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          
          {/* Company Information */}
          <div className="bg-white rounded-xl shadow-md border border-gray-200 p-6">
            <form onSubmit={handleSubmitCompany(onCompanyInfoSubmit)}>
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 bg-indigo-100 rounded-lg flex items-center justify-center">
                  <Building2 className="w-6 h-6 text-indigo-600" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-gray-800">Company Information</h3>
                  <p className="text-sm text-gray-600">Manage your company details</p>
                </div>
              </div>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Company Name</label>
                  <input {...registerCompany('companyName')} className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500" />
                  {errorsCompany.companyName && <p className="text-red-500 text-xs mt-1">{errorsCompany.companyName.message}</p>}
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">GSTIN</label>
                  <input {...registerCompany('gstin')} className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500" />
                  {errorsCompany.gstin && <p className="text-red-500 text-xs mt-1">{errorsCompany.gstin.message}</p>}
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">PAN</label>
                  <input {...registerCompany('pan')} className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500" />
                  {errorsCompany.pan && <p className="text-red-500 text-xs mt-1">{errorsCompany.pan.message}</p>}
                </div>
                <button type="submit" className="w-full px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition-colors">
                  Save Changes
                </button>
              </div>
            </form>
          </div>

          {/* User Profile */}
          <div className="bg-white rounded-xl shadow-md border border-gray-200 p-6">
            <form onSubmit={handleSubmitProfile(onProfileSubmit)}>
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center">
                  <User className="w-6 h-6 text-green-600" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-gray-800">User Profile</h3>
                  <p className="text-sm text-gray-600">Update your profile details</p>
                </div>
              </div>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Full Name</label>
                  <input {...registerProfile('fullName')} className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500" />
                  {errorsProfile.fullName && <p className="text-red-500 text-xs mt-1">{errorsProfile.fullName.message}</p>}
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Email</label>
                  <input type="email" {...registerProfile('email')} className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500" />
                  {errorsProfile.email && <p className="text-red-500 text-xs mt-1">{errorsProfile.email.message}</p>}
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Role</label>
                  <select {...registerProfile('role')} className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white">
                    <option>Accountant</option>
                    <option>Manager</option>
                    <option>Admin</option>
                  </select>
                </div>
                <button type="submit" className="w-full px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors">
                  Update Profile
                </button>
              </div>
            </form>
          </div>

          {/* Security */}
          <div className="bg-white rounded-xl shadow-md border border-gray-200 p-6">
            <form onSubmit={handleSubmitSecurity(onSecuritySubmit)}>
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center">
                  <Lock className="w-6 h-6 text-red-600" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-gray-800">Security</h3>
                  <p className="text-sm text-gray-600">Manage password and security</p>
                </div>
              </div>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Current Password</label>
                  <input type="password" {...registerSecurity('currentPassword')} className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500" />
                  {errorsSecurity.currentPassword && <p className="text-red-500 text-xs mt-1">{errorsSecurity.currentPassword.message}</p>}
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">New Password</label>
                  <input type="password" {...registerSecurity('newPassword')} className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500" />
                  {errorsSecurity.newPassword && <p className="text-red-500 text-xs mt-1">{errorsSecurity.newPassword.message}</p>}
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Confirm Password</label>
                  <input type="password" {...registerSecurity('confirmPassword')} className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500" />
                  {errorsSecurity.confirmPassword && <p className="text-red-500 text-xs mt-1">{errorsSecurity.confirmPassword.message}</p>}
                </div>
                <button type="submit" className="w-full px-4 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors">
                  Change Password
                </button>
              </div>
            </form>
          </div>

          {/* Accounting Preferences */}
          <div className="bg-white rounded-xl shadow-md border border-gray-200 p-6">
            <form onSubmit={handleSubmitPrefs(onPrefsSubmit)}>
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                  <FileText className="w-6 h-6 text-purple-600" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-gray-800">Accounting Preferences</h3>
                  <p className="text-sm text-gray-600">Configure accounting settings</p>
                </div>
              </div>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Financial Year</label>
                  <select {...registerPrefs('financialYear')} className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white">
                    <option>2024-2025</option>
                    <option>2023-2024</option>
                    <option>2022-2023</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Currency</label>
                  <input type="text" defaultValue="INR (₹)" disabled className="w-full px-4 py-2 border border-gray-300 rounded-lg bg-gray-50" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Date Format</label>
                  <select {...registerPrefs('dateFormat')} className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 bg-white">
                    <option>DD/MM/YYYY</option>
                    <option>MM/DD/YYYY</option>
                    <option>YYYY-MM-DD</option>
                  </select>
                </div>
                <button type="submit" className="w-full px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors">
                  Save Preferences
                </button>
              </div>
            </form>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Settings;
