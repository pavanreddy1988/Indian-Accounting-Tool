import React from 'react';
import Header from '../components/Header';
import { Download, Printer } from 'lucide-react';
import toast from 'react-hot-toast';

const BalanceSheet: React.FC = () => {
  const assets = {
    current: [
      { name: 'Cash & Bank', amount: 1245000 },
      { name: 'Accounts Receivable', amount: 856000 },
      { name: 'Inventory', amount: 625000 },
      { name: 'Prepaid Expenses', amount: 125000 }
    ],
    fixed: [
      { name: 'Land & Building', amount: 5000000 },
      { name: 'Plant & Machinery', amount: 2500000 },
      { name: 'Furniture & Fixtures', amount: 450000 },
      { name: 'Vehicles', amount: 800000 },
      { name: 'Less: Accumulated Depreciation', amount: -1250000 }
    ]
  };

  const liabilities = {
    current: [
      { name: 'Accounts Payable', amount: 485000 },
      { name: 'Short-term Loans', amount: 350000 },
      { name: 'Accrued Expenses', amount: 125000 },
      { name: 'GST Payable', amount: 85000 }
    ],
    longTerm: [
      { name: 'Long-term Loans', amount: 2500000 },
      { name: 'Deferred Tax Liability', amount: 250000 }
    ]
  };

  const equity = [
    { name: 'Share Capital', amount: 3000000 },
    { name: 'Retained Earnings', amount: 2500000 },
    { name: 'Current Year Profit', amount: 1111400 }
  ];

  const totalCurrentAssets = assets.current.reduce((sum, item) => sum + item.amount, 0);
  const totalFixedAssets = assets.fixed.reduce((sum, item) => sum + item.amount, 0);
  const totalAssets = totalCurrentAssets + totalFixedAssets;

  const totalCurrentLiabilities = liabilities.current.reduce((sum, item) => sum + item.amount, 0);
  const totalLongTermLiabilities = liabilities.longTerm.reduce((sum, item) => sum + item.amount, 0);
  const totalLiabilities = totalCurrentLiabilities + totalLongTermLiabilities;
  const totalEquity = equity.reduce((sum, item) => sum + item.amount, 0);
  const totalLiabilitiesAndEquity = totalLiabilities + totalEquity;

  return (
    <>
      <Header title="Balance Sheet" />
      
      <main className="p-8">
        <div className="flex justify-between items-center mb-6">
          <div>
            <h3 className="text-lg font-semibold text-gray-800">Balance Sheet</h3>
            <p className="text-sm text-gray-600">As on 31st January 2025</p>
          </div>
          <div className="flex gap-3">
            <button onClick={() => window.print()} className="flex items-center gap-2 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors">
              <Printer className="w-4 h-4" />
              <span className="font-medium">Print</span>
            </button>
            <button onClick={() => toast('PDF export coming soon!')} className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-indigo-600 to-indigo-700 text-white rounded-lg hover:shadow-lg transition-all">
              <Download className="w-4 h-4" />
              <span className="font-medium">Export PDF</span>
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-white rounded-xl shadow-md border border-gray-200 overflow-hidden">
            <div className="bg-gradient-to-r from-blue-600 to-blue-700 text-white px-6 py-4">
              <h4 className="text-lg font-bold">ASSETS</h4>
            </div>
            <div className="p-6">
              <div className="mb-6">
                <h5 className="font-semibold text-gray-800 mb-3 pb-2 border-b border-gray-200">Current Assets</h5>
                {assets.current.map((item, idx) => (
                  <div key={idx} className="flex justify-between py-2 text-sm">
                    <span className="text-gray-700">{item.name}</span>
                    <span className="font-medium text-gray-900">₹{item.amount.toLocaleString('en-IN')}</span>
                  </div>
                ))}
                <div className="flex justify-between py-2 mt-2 bg-blue-50 px-3 -mx-3 rounded">
                  <span className="font-semibold text-gray-800">Total Current Assets</span>
                  <span className="font-bold text-blue-700">₹{totalCurrentAssets.toLocaleString('en-IN')}</span>
                </div>
              </div>

              <div>
                <h5 className="font-semibold text-gray-800 mb-3 pb-2 border-b border-gray-200">Fixed Assets</h5>
                {assets.fixed.map((item, idx) => (
                  <div key={idx} className="flex justify-between py-2 text-sm">
                    <span className={item.amount < 0 ? 'text-gray-600 pl-4' : 'text-gray-700'}>{item.name}</span>
                    <span className={`font-medium ${item.amount < 0 ? 'text-red-600' : 'text-gray-900'}`}>
                      {item.amount < 0 ? '(' : ''}₹{Math.abs(item.amount).toLocaleString('en-IN')}{item.amount < 0 ? ')' : ''}
                    </span>
                  </div>
                ))}
                <div className="flex justify-between py-2 mt-2 bg-blue-50 px-3 -mx-3 rounded">
                  <span className="font-semibold text-gray-800">Total Fixed Assets</span>
                  <span className="font-bold text-blue-700">₹{totalFixedAssets.toLocaleString('en-IN')}</span>
                </div>
              </div>

              <div className="mt-6 pt-4 border-t-2 border-blue-600">
                <div className="flex justify-between py-3 bg-gradient-to-r from-blue-600 to-blue-700 text-white px-4 -mx-6 rounded-lg">
                  <span className="text-lg font-bold">TOTAL ASSETS</span>
                  <span className="text-lg font-bold">₹{totalAssets.toLocaleString('en-IN')}</span>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-md border border-gray-200 overflow-hidden">
            <div className="bg-gradient-to-r from-green-600 to-green-700 text-white px-6 py-4">
              <h4 className="text-lg font-bold">LIABILITIES & EQUITY</h4>
            </div>
            <div className="p-6">
              <div className="mb-6">
                <h5 className="font-semibold text-gray-800 mb-3 pb-2 border-b border-gray-200">Current Liabilities</h5>
                {liabilities.current.map((item, idx) => (
                  <div key={idx} className="flex justify-between py-2 text-sm">
                    <span className="text-gray-700">{item.name}</span>
                    <span className="font-medium text-gray-900">₹{item.amount.toLocaleString('en-IN')}</span>
                  </div>
                ))}
                <div className="flex justify-between py-2 mt-2 bg-orange-50 px-3 -mx-3 rounded">
                  <span className="font-semibold text-gray-800">Total Current Liabilities</span>
                  <span className="font-bold text-orange-700">₹{totalCurrentLiabilities.toLocaleString('en-IN')}</span>
                </div>
              </div>

              <div className="mb-6">
                <h5 className="font-semibold text-gray-800 mb-3 pb-2 border-b border-gray-200">Long-term Liabilities</h5>
                {liabilities.longTerm.map((item, idx) => (
                  <div key={idx} className="flex justify-between py-2 text-sm">
                    <span className="text-gray-700">{item.name}</span>
                    <span className="font-medium text-gray-900">₹{item.amount.toLocaleString('en-IN')}</span>
                  </div>
                ))}
                <div className="flex justify-between py-2 mt-2 bg-orange-50 px-3 -mx-3 rounded">
                  <span className="font-semibold text-gray-800">Total Long-term Liabilities</span>
                  <span className="font-bold text-orange-700">₹{totalLongTermLiabilities.toLocaleString('en-IN')}</span>
                </div>
              </div>

              <div>
                <h5 className="font-semibold text-gray-800 mb-3 pb-2 border-b border-gray-200">Equity</h5>
                {equity.map((item, idx) => (
                  <div key={idx} className="flex justify-between py-2 text-sm">
                    <span className="text-gray-700">{item.name}</span>
                    <span className="font-medium text-gray-900">₹{item.amount.toLocaleString('en-IN')}</span>
                  </div>
                ))}
                <div className="flex justify-between py-2 mt-2 bg-green-50 px-3 -mx-3 rounded">
                  <span className="font-semibold text-gray-800">Total Equity</span>
                  <span className="font-bold text-green-700">₹{totalEquity.toLocaleString('en-IN')}</span>
                </div>
              </div>

              <div className="mt-6 pt-4 border-t-2 border-green-600">
                <div className="flex justify-between py-3 bg-gradient-to-r from-green-600 to-green-700 text-white px-4 -mx-6 rounded-lg">
                  <span className="text-lg font-bold">TOTAL LIABILITIES & EQUITY</span>
                  <span className="text-lg font-bold">₹{totalLiabilitiesAndEquity.toLocaleString('en-IN')}</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="bg-gradient-to-br from-indigo-500 to-indigo-600 rounded-xl p-6 text-white shadow-lg">
            <p className="text-sm opacity-90 mb-2">Current Ratio</p>
            <p className="text-3xl font-bold">{(totalCurrentAssets / totalCurrentLiabilities).toFixed(2)}:1</p>
            <p className="text-xs opacity-75 mt-2">Current Assets / Current Liabilities</p>
          </div>
          <div className="bg-gradient-to-br from-purple-500 to-purple-600 rounded-xl p-6 text-white shadow-lg">
            <p className="text-sm opacity-90 mb-2">Debt-to-Equity Ratio</p>
            <p className="text-3xl font-bold">{(totalLiabilities / totalEquity).toFixed(2)}:1</p>
            <p className="text-xs opacity-75 mt-2">Total Liabilities / Total Equity</p>
          </div>
          <div className="bg-gradient-to-br from-pink-500 to-pink-600 rounded-xl p-6 text-white shadow-lg">
            <p className="text-sm opacity-90 mb-2">Equity Ratio</p>
            <p className="text-3xl font-bold">{((totalEquity / totalAssets) * 100).toFixed(2)}%</p>
            <p className="text-xs opacity-75 mt-2">Total Equity / Total Assets</p>
          </div>
        </div>
      </main>
    </>
  );
};

export default BalanceSheet;
