import React from 'react';
import { Link } from 'react-router-dom';
import Header from '../components/Header';
import StatCard from '../components/StatCard';
import { IndianRupee, TrendingUp, TrendingDown, FileText, ShoppingCart } from 'lucide-react';
import ReactECharts from 'echarts-for-react';

const Dashboard: React.FC = () => {
  const revenueChartOption = {
    tooltip: {
      trigger: 'axis',
      axisPointer: { type: 'shadow' }
    },
    legend: {
      data: ['Revenue', 'Expenses']
    },
    xAxis: {
      type: 'category',
      data: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun']
    },
    yAxis: {
      type: 'value',
      axisLabel: {
        formatter: '₹{value}'
      }
    },
    series: [
      {
        name: 'Revenue',
        type: 'bar',
        data: [450000, 520000, 490000, 610000, 580000, 650000],
        itemStyle: { color: '#4F46E5' }
      },
      {
        name: 'Expenses',
        type: 'bar',
        data: [320000, 380000, 350000, 420000, 410000, 460000],
        itemStyle: { color: '#F59E0B' }
      }
    ]
  };

  const pieChartOption = {
    tooltip: {
      trigger: 'item',
      formatter: '{b}: ₹{c} ({d}%)'
    },
    legend: {
      orient: 'vertical',
      left: 'left'
    },
    series: [
      {
        name: 'Expenses',
        type: 'pie',
        radius: '60%',
        data: [
          { value: 150000, name: 'Salaries', itemStyle: { color: '#4F46E5' } },
          { value: 90000, name: 'Rent', itemStyle: { color: '#10B981' } },
          { value: 120000, name: 'Operations', itemStyle: { color: '#F59E0B' } },
          { value: 60000, name: 'Marketing', itemStyle: { color: '#EF4444' } },
          { value: 40000, name: 'Utilities', itemStyle: { color: '#8B5CF6' } }
        ],
        emphasis: {
          itemStyle: {
            shadowBlur: 10,
            shadowOffsetX: 0,
            shadowColor: 'rgba(0, 0, 0, 0.5)'
          }
        }
      }
    ]
  };

  const quickActions = [
    { to: '/invoices', icon: FileText, label: 'New Invoice', color: 'from-indigo-500 to-indigo-600' },
    { to: '/journal', icon: ShoppingCart, label: 'New Purchase', color: 'from-green-500 to-green-600' },
    { to: '/journal', icon: IndianRupee, label: 'Journal Entry', color: 'from-orange-500 to-orange-600' },
    { to: '/profit-loss', icon: TrendingUp, label: 'View Reports', color: 'from-purple-500 to-purple-600' },
  ];

  return (
    <div className="w-full min-h-screen bg-gray-50">
      <Header title="Dashboard" />
      
      <main className="p-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <StatCard
            title="Total Revenue"
            value="₹32,45,600"
            icon={TrendingUp}
            trend="12.5% from last month"
            trendUp={true}
            color="blue"
          />
          <StatCard
            title="Total Expenses"
            value="₹21,34,200"
            icon={TrendingDown}
            trend="5.3% from last month"
            trendUp={false}
            color="orange"
          />
          <StatCard
            title="Net Profit"
            value="₹11,11,400"
            icon={IndianRupee}
            trend="18.2% from last month"
            trendUp={true}
            color="green"
          />
          <StatCard
            title="Pending Invoices"
            value="24"
            icon={FileText}
            color="purple"
          />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          <div className="bg-white rounded-xl shadow-md border border-gray-200 p-6">
            <h3 className="text-lg font-semibold text-gray-800 mb-4">Revenue vs Expenses</h3>
            <ReactECharts option={revenueChartOption} style={{ height: '300px' }} />
          </div>
          
          <div className="bg-white rounded-xl shadow-md border border-gray-200 p-6">
            <h3 className="text-lg font-semibold text-gray-800 mb-4">Expense Breakdown</h3>
            <ReactECharts option={pieChartOption} style={{ height: '300px' }} />
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="bg-white rounded-xl shadow-md border border-gray-200 p-6">
            <h3 className="text-lg font-semibold text-gray-800 mb-4">Recent Transactions</h3>
            <div className="space-y-3">
              {[
                { desc: 'Office Rent Payment', amount: '-₹45,000', date: '15 Jan 2025', type: 'expense' },
                { desc: 'Client Invoice #1234', amount: '+₹1,25,000', date: '14 Jan 2025', type: 'income' },
                { desc: 'Salary Payment', amount: '-₹2,50,000', date: '10 Jan 2025', type: 'expense' },
                { desc: 'Sales Revenue', amount: '+₹85,000', date: '08 Jan 2025', type: 'income' }
              ].map((txn, idx) => (
                <div key={idx} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors">
                  <div className="flex items-center space-x-3">
                    <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                      txn.type === 'income' ? 'bg-green-100' : 'bg-red-100'
                    }`}>
                      {txn.type === 'income' ? (
                        <TrendingUp className="w-5 h-5 text-green-600" />
                      ) : (
                        <TrendingDown className="w-5 h-5 text-red-600" />
                      )}
                    </div>
                    <div>
                      <p className="font-medium text-gray-800">{txn.desc}</p>
                      <p className="text-sm text-gray-500">{txn.date}</p>
                    </div>
                  </div>
                  <span className={`font-semibold ${
                    txn.type === 'income' ? 'text-green-600' : 'text-red-600'
                  }`}>
                    {txn.amount}
                  </span>
                </div>
              ))}
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-md border border-gray-200 p-6">
            <h3 className="text-lg font-semibold text-gray-800 mb-4">Quick Actions</h3>
            <div className="grid grid-cols-2 gap-4">
              {quickActions.map((action) => (
                <Link
                  key={action.label}
                  to={action.to}
                  className={`flex flex-col items-center justify-center p-6 bg-gradient-to-br ${action.color} text-white rounded-lg hover:shadow-lg transition-all`}
                >
                  <action.icon className="w-8 h-8 mb-2" />
                  <span className="text-sm font-medium">{action.label}</span>
                </Link>
              ))}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Dashboard;
