import React, { useState, useEffect } from 'react';
import Header from '../components/Header';
import Modal from '../components/Modal';
import { Plus, Download, Edit2, Trash2 } from 'lucide-react';
import { generateMockDepreciationAssets } from '../data/mockData';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { DepreciationAsset } from '../types/accounting';
import toast from 'react-hot-toast';
import { faker } from '@faker-js/faker';

const assetSchema = z.object({
  assetName: z.string().min(3, 'Asset name is required'),
  assetCode: z.string().min(3, 'Asset code is required'),
  category: z.string().min(3, 'Category is required'),
  purchaseDate: z.string().min(1, 'Purchase date is required'),
  purchaseValue: z.preprocess(v => parseFloat(String(v || '0')), z.number().positive('Must be > 0')),
  depreciationMethod: z.enum(['SLM', 'WDV']),
  depreciationRate: z.preprocess(v => parseFloat(String(v || '0')), z.number().positive('Rate must be > 0').max(100)),
  usefulLife: z.preprocess(v => parseInt(String(v || '0'), 10), z.number().positive('Must be > 0')),
});

type AssetFormData = z.infer<typeof assetSchema>;

const Depreciation: React.FC = () => {
  const [assets, setAssets] = useState(generateMockDepreciationAssets());
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingAsset, setEditingAsset] = useState<DepreciationAsset | null>(null);

  const { register, handleSubmit, reset, formState: { errors } } = useForm<AssetFormData>({
    resolver: zodResolver(assetSchema),
  });

  useEffect(() => {
    if (editingAsset) {
      reset(editingAsset);
    } else {
      reset({
        assetName: '', assetCode: '', category: '', purchaseDate: '', purchaseValue: 0,
        depreciationMethod: 'WDV', depreciationRate: 15, usefulLife: 7
      });
    }
  }, [editingAsset, reset]);

  const handleFormSubmit = (data: AssetFormData) => {
    if (editingAsset) {
      const updatedAsset: DepreciationAsset = {
        ...editingAsset,
        ...data,
        writtenDownValue: data.purchaseValue - editingAsset.accumulatedDepreciation,
      };
      setAssets(prev => prev.map(a => a.id === editingAsset.id ? updatedAsset : a));
      toast.success('Asset updated successfully!');
    } else {
      const newAsset: DepreciationAsset = {
        id: faker.string.uuid(),
        ...data,
        accumulatedDepreciation: 0,
        writtenDownValue: data.purchaseValue,
      };
      setAssets(prev => [newAsset, ...prev]);
      toast.success('Asset added successfully!');
    }
    closeModal();
  };

  const handleDeleteAsset = (assetId: string) => {
    if (window.confirm('Are you sure you want to delete this asset?')) {
      setAssets(prev => prev.filter(asset => asset.id !== assetId));
      toast.success('Asset deleted successfully!');
    }
  };

  const openModal = (asset: DepreciationAsset | null) => {
    setEditingAsset(asset);
    setIsModalOpen(true);
  };

  const closeModal = () => {
    setIsModalOpen(false);
    setEditingAsset(null);
  };

  return (
    <div className="w-full min-h-screen bg-gray-50">
      <Header title="Depreciation Schedule" />
      
      <main className="p-8">
        <div className="flex justify-between items-center mb-6">
          <p className="text-gray-600">Manage fixed assets and calculate depreciation as per Indian standards</p>
          <div className="flex gap-3">
            <button onClick={() => toast('Export functionality coming soon!')} className="flex items-center gap-2 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors">
              <Download className="w-4 h-4" />
              <span className="font-medium">Export</span>
            </button>
            <button onClick={() => openModal(null)} className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-indigo-600 to-indigo-700 text-white rounded-lg hover:shadow-lg transition-all">
              <Plus className="w-4 h-4" />
              <span className="font-medium">Add Asset</span>
            </button>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-md border border-gray-200 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 border-b border-gray-200">
                <tr>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Asset Code</th>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Asset Name</th>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Category</th>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Purchase Date</th>
                  <th className="px-6 py-4 text-right text-xs font-semibold text-gray-600 uppercase tracking-wider">Purchase Value</th>
                  <th className="px-6 py-4 text-center text-xs font-semibold text-gray-600 uppercase tracking-wider">Method</th>
                  <th className="px-6 py-4 text-center text-xs font-semibold text-gray-600 uppercase tracking-wider">Rate (%)</th>
                  <th className="px-6 py-4 text-right text-xs font-semibold text-gray-600 uppercase tracking-wider">Accumulated Dep.</th>
                  <th className="px-6 py-4 text-right text-xs font-semibold text-gray-600 uppercase tracking-wider">WDV</th>
                  <th className="px-6 py-4 text-center text-xs font-semibold text-gray-600 uppercase tracking-wider">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {assets.map((asset) => (
                  <tr key={asset.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className="font-mono text-sm font-medium text-indigo-600">{asset.assetCode}</span>
                    </td>
                    <td className="px-6 py-4">
                      <span className="text-sm font-medium text-gray-900">{asset.assetName}</span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className="inline-flex px-3 py-1 text-xs font-semibold rounded-full bg-purple-100 text-purple-800">
                        {asset.category}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className="text-sm text-gray-700">{new Date(asset.purchaseDate).toLocaleDateString('en-IN')}</span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right">
                      <span className="text-sm font-medium text-gray-900">₹{asset.purchaseValue.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-center">
                      <span className={`inline-flex px-3 py-1 text-xs font-semibold rounded-full ${
                        asset.depreciationMethod === 'SLM' ? 'bg-blue-100 text-blue-800' : 'bg-green-100 text-green-800'
                      }`}>
                        {asset.depreciationMethod}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-center">
                      <span className="text-sm font-medium text-gray-900">{asset.depreciationRate}%</span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right">
                      <span className="text-sm font-medium text-red-600">₹{asset.accumulatedDepreciation.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-right">
                      <span className="text-sm font-semibold text-gray-900">₹{asset.writtenDownValue.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-center">
                      <div className="flex items-center justify-center gap-2">
                        <button onClick={() => openModal(asset)} className="p-2 text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors">
                          <Edit2 className="w-4 h-4" />
                        </button>
                        <button onClick={() => handleDeleteAsset(asset.id)} className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors">
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
              <tfoot className="bg-gray-50 font-semibold">
                <tr>
                  <td colSpan={4} className="px-6 py-4 text-right text-sm font-bold text-gray-900 uppercase">Total</td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-bold text-gray-900">
                    ₹{assets.reduce((sum, a) => sum + a.purchaseValue, 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </td>
                  <td colSpan={3}></td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-bold text-red-600">
                    ₹{assets.reduce((sum, a) => sum + a.accumulatedDepreciation, 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-bold text-gray-900">
                    ₹{assets.reduce((sum, a) => sum + a.writtenDownValue, 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </td>
                  <td></td>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>

        <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl p-6 text-white shadow-lg">
            <p className="text-sm opacity-90 mb-2">Depreciation Methods</p>
            <div className="space-y-2 mt-4">
              <div className="flex justify-between items-center">
                <span className="text-sm">SLM (Straight Line Method)</span>
                <span className="font-semibold">{assets.filter(a => a.depreciationMethod === 'SLM').length} assets</span>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm">WDV (Written Down Value)</span>
                <span className="font-semibold">{assets.filter(a => a.depreciationMethod === 'WDV').length} assets</span>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl border border-gray-200 p-6">
            <h4 className="font-semibold text-gray-800 mb-4">Depreciation Notes</h4>
            <ul className="space-y-2 text-sm text-gray-600">
              <li className="flex items-start gap-2">
                <span className="text-indigo-600 mt-1">•</span>
                <span>SLM: Equal depreciation charged every year</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-indigo-600 mt-1">•</span>
                <span>WDV: Depreciation on reducing balance method</span>
              </li>
              <li className="flex items-start gap-2">
                <span className="text-indigo-600 mt-1">•</span>
                <span>Rates as per Income Tax Act, 1961</span>
              </li>
            </ul>
          </div>
        </div>
      </main>
      
      <Modal title={editingAsset ? "Edit Fixed Asset" : "Add New Fixed Asset"} isOpen={isModalOpen} onClose={closeModal}>
        <form onSubmit={handleSubmit(handleFormSubmit)} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">Asset Name</label>
              <input {...register('assetName')} className="mt-1 block w-full input" />
              {errors.assetName && <p className="text-red-500 text-xs mt-1">{errors.assetName.message}</p>}
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">Asset Code</label>
              <input {...register('assetCode')} className="mt-1 block w-full input" />
              {errors.assetCode && <p className="text-red-500 text-xs mt-1">{errors.assetCode.message}</p>}
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700">Category</label>
            <input {...register('category')} className="mt-1 block w-full input" />
            {errors.category && <p className="text-red-500 text-xs mt-1">{errors.category.message}</p>}
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">Purchase Date</label>
              <input type="date" {...register('purchaseDate')} className="mt-1 block w-full input" />
              {errors.purchaseDate && <p className="text-red-500 text-xs mt-1">{errors.purchaseDate.message}</p>}
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">Purchase Value (₹)</label>
              <input type="number" step="0.01" {...register('purchaseValue')} className="mt-1 block w-full input" />
              {errors.purchaseValue && <p className="text-red-500 text-xs mt-1">{errors.purchaseValue.message}</p>}
            </div>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700">Method</label>
              <select {...register('depreciationMethod')} className="mt-1 block w-full input">
                <option value="WDV">WDV</option>
                <option value="SLM">SLM</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">Rate (%)</label>
              <input type="number" step="0.01" {...register('depreciationRate')} className="mt-1 block w-full input" />
              {errors.depreciationRate && <p className="text-red-500 text-xs mt-1">{errors.depreciationRate.message}</p>}
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700">Useful Life (Yrs)</label>
              <input type="number" {...register('usefulLife')} className="mt-1 block w-full input" />
              {errors.usefulLife && <p className="text-red-500 text-xs mt-1">{errors.usefulLife.message}</p>}
            </div>
          </div>
          <div className="flex justify-end gap-3 pt-4 border-t">
            <button type="button" onClick={closeModal} className="px-4 py-2 bg-gray-200 text-gray-800 rounded-lg hover:bg-gray-300">Cancel</button>
            <button type="submit" className="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700">{editingAsset ? "Save Changes" : "Add Asset"}</button>
          </div>
        </form>
      </Modal>
    </div>
  );
};

export default Depreciation;
