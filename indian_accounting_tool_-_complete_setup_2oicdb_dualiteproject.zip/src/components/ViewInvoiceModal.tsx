import React from 'react';
import Modal from './Modal';
import { Invoice } from '../types/accounting';
import { IndianRupee } from 'lucide-react';

interface ViewInvoiceModalProps {
  isOpen: boolean;
  onClose: () => void;
  invoice: Invoice | null;
}

const ViewInvoiceModal: React.FC<ViewInvoiceModalProps> = ({ isOpen, onClose, invoice }) => {
  if (!invoice) return null;

  return (
    <Modal isOpen={isOpen} onClose={onClose} title={`Invoice: ${invoice.invoiceNumber}`}>
      <div className="p-4 bg-gray-50 rounded-lg">
        <div className="flex justify-between items-start mb-6">
          <div>
            <div className="flex items-center space-x-3 mb-4">
              <div className="w-12 h-12 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-lg flex items-center justify-center shadow-lg">
                <IndianRupee className="w-7 h-7 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-800">AccounTech</h1>
                <p className="text-sm text-gray-500">Invoice</p>
              </div>
            </div>
            <p className="text-sm text-gray-600">Billed to:</p>
            <p className="font-semibold text-gray-800">{invoice.customerName}</p>
          </div>
          <div className="text-right">
            <p className="font-bold text-lg text-gray-800">{invoice.invoiceNumber}</p>
            <p className="text-sm text-gray-600">Date: {new Date(invoice.date).toLocaleDateString('en-IN')}</p>
            <p className={`mt-2 text-sm font-bold px-3 py-1 rounded-full inline-block ${
              invoice.status === 'Paid' ? 'bg-green-100 text-green-800' :
              invoice.status === 'Overdue' ? 'bg-red-100 text-red-800' :
              'bg-blue-100 text-blue-800'
            }`}>
              Status: {invoice.status}
            </p>
          </div>
        </div>

        <table className="w-full mb-6">
          <thead className="bg-gray-200">
            <tr>
              <th className="px-4 py-2 text-left text-xs font-semibold text-gray-600 uppercase">Description</th>
              <th className="px-4 py-2 text-right text-xs font-semibold text-gray-600 uppercase">Qty</th>
              <th className="px-4 py-2 text-right text-xs font-semibold text-gray-600 uppercase">Rate</th>
              <th className="px-4 py-2 text-right text-xs font-semibold text-gray-600 uppercase">Amount</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {invoice.items.map((item, index) => (
              <tr key={index}>
                <td className="px-4 py-3 text-sm text-gray-800">{item.description}</td>
                <td className="px-4 py-3 text-sm text-gray-800 text-right">{item.quantity}</td>
                <td className="px-4 py-3 text-sm text-gray-800 text-right">₹{item.rate.toFixed(2)}</td>
                <td className="px-4 py-3 text-sm text-gray-800 text-right">₹{item.amount.toFixed(2)}</td>
              </tr>
            ))}
          </tbody>
        </table>

        <div className="flex justify-end">
          <div className="w-full max-w-xs">
            <div className="flex justify-between py-2 border-b">
              <span className="text-sm text-gray-600">Subtotal</span>
              <span className="text-sm font-medium text-gray-800">₹{invoice.subtotal.toFixed(2)}</span>
            </div>
            <div className="flex justify-between py-2 border-b">
              <span className="text-sm text-gray-600">CGST</span>
              <span className="text-sm font-medium text-gray-800">₹{invoice.cgst.toFixed(2)}</span>
            </div>
            <div className="flex justify-between py-2 border-b">
              <span className="text-sm text-gray-600">SGST</span>
              <span className="text-sm font-medium text-gray-800">₹{invoice.sgst.toFixed(2)}</span>
            </div>
            <div className="flex justify-between py-3 bg-gray-200 px-3 rounded-b-lg mt-2">
              <span className="text-md font-bold text-gray-900">Total</span>
              <span className="text-md font-bold text-gray-900">₹{invoice.total.toFixed(2)}</span>
            </div>
          </div>
        </div>
      </div>
    </Modal>
  );
};

export default ViewInvoiceModal;
