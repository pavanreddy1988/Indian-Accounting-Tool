import React from 'react';
import { NavLink } from 'react-router-dom';
import { LayoutDashboard, BookOpen, FileText, TrendingUp, BarChart3, Percent, IndianRupee, Settings, FileSpreadsheet, Calculator } from 'lucide-react';

const Sidebar: React.FC = () => {
  const navItems = [
    { icon: LayoutDashboard, label: 'Dashboard', path: '/' },
    { icon: BookOpen, label: 'Chart of Accounts', path: '/accounts' },
    { icon: FileText, label: 'Journal Entries', path: '/journal' },
    { icon: Calculator, label: 'Trial Balance', path: '/trial-balance' },
    { icon: TrendingUp, label: 'Profit & Loss', path: '/profit-loss' },
    { icon: FileSpreadsheet, label: 'Balance Sheet', path: '/balance-sheet' },
    { icon: BarChart3, label: 'Depreciation', path: '/depreciation' },
    { icon: Percent, label: 'GST Returns', path: '/gst' },
    { icon: IndianRupee, label: 'Invoices', path: '/invoices' },
    { icon: Settings, label: 'Settings', path: '/settings' },
  ];

  return (
    <aside className="w-64 bg-gradient-to-b from-indigo-900 to-indigo-800 text-white min-h-screen fixed left-0 top-0 overflow-y-auto shadow-2xl">
      <div className="p-6 border-b border-indigo-700">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-lg flex items-center justify-center shadow-lg">
            <IndianRupee className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-xl font-bold">AccounTech</h1>
            <p className="text-xs text-indigo-300">Indian Accounting</p>
          </div>
        </div>
      </div>
      
      <nav className="p-4 space-y-1">
        {navItems.map(({ icon: Icon, label, path }) => (
          <NavLink
            key={path}
            to={path}
            className={({ isActive }) =>
              `flex items-center space-x-3 px-4 py-3 rounded-lg transition-all duration-200 ${
                isActive
                  ? 'bg-indigo-700 shadow-lg text-white'
                  : 'text-indigo-200 hover:bg-indigo-800 hover:text-white'
              }`
            }
          >
            <Icon className="w-5 h-5" />
            <span className="font-medium text-sm">{label}</span>
          </NavLink>
        ))}
      </nav>
      
      <div className="absolute bottom-0 left-0 right-0 p-4 border-t border-indigo-700">
        <div className="bg-indigo-800 rounded-lg p-3 text-xs">
          <p className="text-indigo-300 mb-1">Financial Year</p>
          <p className="font-semibold">2024-2025</p>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;
