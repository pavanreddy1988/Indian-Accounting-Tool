export interface Account {
  id: string;
  code: string;
  name: string;
  type: 'Asset' | 'Liability' | 'Equity' | 'Revenue' | 'Expense';
  subType: string;
  balance: number;
  openingBalance: number;
  isActive: boolean;
}

export interface JournalEntry {
  id: string;
  date: string;
  voucherNumber: string;
  description: string;
  entries: TransactionEntry[];
  createdBy: string;
  status: 'Draft' | 'Posted' | 'Cancelled';
}

export interface TransactionEntry {
  accountId: string;
  accountName: string;
  debit: number;
  credit: number;
  narration?: string;
}

export interface TrialBalance {
  accountCode: string;
  accountName: string;
  debit: number;
  credit: number;
}

export interface BalanceSheetItem {
  name: string;
  amount: number;
  children?: BalanceSheetItem[];
}

export interface ProfitLossItem {
  name: string;
  amount: number;
  children?: ProfitLossItem[];
}

export interface DepreciationAsset {
  id: string;
  assetName: string;
  assetCode: string;
  category: string;
  purchaseDate: string;
  purchaseValue: number;
  depreciationMethod: 'SLM' | 'WDV';
  depreciationRate: number;
  accumulatedDepreciation: number;
  writtenDownValue: number;
  usefulLife: number;
}

export interface GSTReturn {
  id: string;
  month: string;
  year: number;
  gstr1Filed: boolean;
  gstr3bFiled: boolean;
  totalSales: number;
  totalPurchases: number;
  outputGST: number;
  inputGST: number;
  netGST: number;
  status: 'Pending' | 'Filed' | 'Revised';
}

export interface Invoice {
  id: string;
  invoiceNumber: string;
  date: string;
  customerName: string;
  items: InvoiceItem[];
  subtotal: number;
  cgst: number;
  sgst: number;
  igst: number;
  total: number;
  status: 'Draft' | 'Sent' | 'Paid' | 'Overdue';
}

export interface InvoiceItem {
  description: string;
  quantity: number;
  rate: number;
  gstRate: number;
  amount: number;
}
