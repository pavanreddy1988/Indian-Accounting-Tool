
// Preload script for TallyPro Electron app
// Keeps contextIsolation enabled and exposes nothing by default.
// Add secure APIs here if needed in future.
window.addEventListener('DOMContentLoaded', () => {
  // no-op for now
});
