
# TallyPro Electron App (scaffold)

This directory contains a ready-to-run Electron scaffold that wraps `TallyPro.html` into a desktop app.

## What's included
- `TallyPro.html` — your offline accounting tool (already embedded).
- `main.js` — Electron main process file that loads `TallyPro.html`.
- `preload.js` — safe preload script (currently a no-op).
- `package.json` — scripts and `electron-builder` configuration for packaging.
- `build/icon.png` — placeholder app icon (simple PNG).

## Run locally (development)
1. Install Node.js (v18+ recommended) and npm.
2. From this folder, run:
   ```bash
   npm install
   npm run start
   ```
   This launches the app in a desktop window.

## Build distributables (.exe / .app)
To create installers for Windows and macOS, use `electron-builder` (already configured in `package.json`).
From this folder, run:
   ```bash
   npm install
   npm run dist
   ```
- On **Windows**, this produces `nsis` installer and zip in `dist/`.
- On **macOS**, this produces `dmg` and zip in `dist/`.

**Note:** Building requires internet access to download Electron binaries. For automated CI (GitHub Actions), set up proper runners and secrets if needed.

## Customization ideas
- Add native menus or tray icon in `main.js`.
- Expose secure filesystem APIs via `preload.js` with `contextBridge` if you want save/load functionality.
- Replace `build/icon.png` with your high-resolution app icons for each platform (ICNS/ICO) for better packaging.

## License
MIT
